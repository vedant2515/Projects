document.addEventListener('DOMContentLoaded', function() {
    const loginButton = document.getElementById('loginButton');

    loginButton.addEventListener('click', function() {
        window.location.href = 'login.html'; // Replace with the actual login page URL
    });
});

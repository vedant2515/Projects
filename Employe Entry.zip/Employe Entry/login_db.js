const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();

// Parse incoming requests
app.use(bodyParser.urlencoded({ extended: true }));

// Connect to MySQL Database
const db = mysql.createConnection({
    host: 'localhost',  // Database host
    user: 'root',       // MySQL username
    password: '9856',       // MySQL password
    database: 'login_db' // Database name
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to the MySQL database');
});

// Handle POST request for login
app.post('/login', (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    // Insert data into the database
    const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
    db.query(query, [username, password], (err, result) => {
        if (err) {
            console.error('Error inserting into database:', err);
            res.status(500).send('Error saving data');
        } else {
            res.send('User data saved successfully');
        }
    });
});

// Start server on port 3000
app.listen(3000, () => {
    console.log('Server started on http://localhost:3000');
});
